/*
 * Phillip Sorrell Radke
 * This work is my own.
 */

/**
 *
 * @author Phillip
 */
public interface Comparable {
	
}
